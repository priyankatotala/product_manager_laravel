<?php declare(strict_types=1);

return [
    'flower' => 'sakura',
    'olive' => 'peace',
    'pos1' => [
        'sunflower' => 'love'
    ],
    'pos2' => [
        'cornflower' => 'elegant'
    ],
    'array' => [
        'A',
        'B',
        'C'
    ],
];
