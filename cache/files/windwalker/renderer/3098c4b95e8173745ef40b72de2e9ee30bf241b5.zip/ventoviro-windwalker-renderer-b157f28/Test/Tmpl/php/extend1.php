<?php declare(strict_types=1);
/**
 * Part of Windwalker project.
 *
 * @copyright  Copyright (C) 2019 LYRASOFT.
 * @license    LGPL-2.0-or-later
 */

?>
<p>
    Lorem ipsum dolor sit amet,
    <?php $this->block('sakura'); ?>
    consectetur adipiscing elit.
    <?php $this->endBlock(); ?>
    Curabitur eleifend, ante vitae vestibulum tempus
</p>
