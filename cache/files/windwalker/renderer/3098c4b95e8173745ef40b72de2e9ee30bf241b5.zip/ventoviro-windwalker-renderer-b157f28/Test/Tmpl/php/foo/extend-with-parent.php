<?php declare(strict_types=1);
/**
 * Part of Windwalker project.
 *
 * @copyright  Copyright (C) 2019 LYRASOFT.
 * @license    LGPL-2.0-or-later
 */

?>

<?php $this->extend('foo/extend2'); ?>

<?php $this->block('sakura'); ?>
<?php echo $this->parent(); ?>
<span>Sed tempor urna quis varius luctus.</span>
<?php $this->endblock(); ?>
