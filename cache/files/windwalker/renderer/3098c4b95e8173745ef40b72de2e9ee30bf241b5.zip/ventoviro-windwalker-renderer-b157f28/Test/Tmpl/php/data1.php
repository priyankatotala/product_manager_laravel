<?php declare(strict_types=1);
/**
 * Part of Windwalker project.
 *
 * @copyright  Copyright (C) 2019 LYRASOFT.
 * @license    LGPL-2.0-or-later
 */

?>

<div id="data" class="<?php echo $class; ?>">
    <?php echo $this->load('foo/data2'); ?>
</div>
