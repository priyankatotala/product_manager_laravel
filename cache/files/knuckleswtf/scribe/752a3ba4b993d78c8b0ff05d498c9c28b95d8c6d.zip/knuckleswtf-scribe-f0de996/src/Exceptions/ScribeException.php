<?php

namespace Knuckles\Scribe\Exceptions;

interface ScribeException
{
}
