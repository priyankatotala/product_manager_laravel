<?php

namespace Knuckles\Scribe\Tools;

class Flags
{
    public static $shouldBeVerbose = false;
}
