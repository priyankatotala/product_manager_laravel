<?php

namespace Silly\Command;

/**
 * The expression that defines the command is invalid.
 *
 * @author Matthieu Napoli <matthieu@mnapoli.fr>
 */
class InvalidCommandExpression extends \InvalidArgumentException
{
}
